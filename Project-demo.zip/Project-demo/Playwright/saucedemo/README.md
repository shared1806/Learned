# Cài dotenv để Playwright tự động đọc file .env
npm install dotenv
