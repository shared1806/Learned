1. Select * from table / Select * from table WHERE ...
2. Select * from tableA JOIN tableB On tableA.ID = tableB.ID;
3. Select * from table ORDER BY id
4. SELECT customer_id, COUNT(*) FROM orders GROUP BY customer_id;