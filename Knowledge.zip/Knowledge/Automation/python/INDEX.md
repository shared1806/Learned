1. Biến + Chuỗi + Cắt chuỗi + Format chuỗi: Variables.py
2. Phạm vi biến: Variable_Scope.py
3. Function chuỗi: String_Functions.py
4. Toán tử: Operators.py
5. List: Lists.py
6. List Method:  List_Methods.py
7. Set: Sets.py
8. Tuple: Tuples.py
9. Dictionaries: Dictionaries.py
10. If else + For + While + Break and Continue:  If_Else.py
11. ZIP: Zip.py
12. Range Function: Range.py
13. Function: Functions.py
14. Return Statement: Return.py 
15. Keyword and Positional Arguments: Keyword _Positional_Arguments.py
16. Phạm vi biến: Variable_Scope.py
17. Built In Functions: Built_Functions.py
18. Datetime Module: Datetime_Module.py
19. Đối tượng OOP: Objects_Methods.py
20. Classes và Objects: Classes_Objects.py 
21. Class Variables vs Instance: Class_Variables_Instance.py
22. Kế thừa: Inheritance.py
23. Đa kế thừa: Multiple_Inheritance.py
24. Modules: MyModules
- Là cách mà chúng ta phân hóa chương trình ra các nhánh nhỏ cho dễ quản lý và gọi lại chúng khi nào cần, như thế chương trình của chúng ta sẽ có tính tái sử dụng, bảo trì cao
25. Xử lý ngoại lệ: Exception_Handling.py
26. Viết - Đọc file: FileIODemo -> Write_Files.py -> Read_File.py
27. Write Data to Excel:  FileIODemo -> write_xls.py -> read_xls.py
28. Tạo data giả Faker: Generate_Test_Data.py

*** https://tek4.vn/chung-chi/chi-tiet/1348 *** 

*** Tham khảo: https://www.youtube.com/watch?v=dc-Ilcs9CM8&list=PLL34mf651faPg74A-vy1TIPWUjYBIJ52n *** 