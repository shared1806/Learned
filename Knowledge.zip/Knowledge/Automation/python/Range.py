x = range(3, 6)

for n in x:
  print(n)