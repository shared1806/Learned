class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def get_name(self):
        print("I am", self.name)

def phep_cong(a,b):
    return a+b

list_fruists = ["Apple","Mango","Cheery","Guava","Lemon"]