def myFunc():
    return 3+3
print(myFunc())