# Tuples là một kiểu dữ liệu dùng để lưu trữ các đối tượng có thứ tự và bất biến không thay đổi được

# count
thistuple = (1, 3, 7, 8, 7, 5, 4, 6, 8, 5)
x = thistuple.count(5)
print(x)

# index: tìm vị trí của phần tử có value = 8
x = thistuple.index(8)
print(x)