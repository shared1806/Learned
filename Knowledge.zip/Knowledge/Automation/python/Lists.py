x = 10
y = "training"

z = [10, 20, 40, 50]
a = ['apple', 'banana', 'guava', 'orange']
b = [10, "20", 40, 50]

print(a[2])
print(a[-1])
print(a[0:2])
print(a[0:3:2])