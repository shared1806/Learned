f =  open("/Users/trangntt/Documents/Martha/Learns/python/FileIODemo/write_demo.txt", "r")
print(f.read())
f.close()