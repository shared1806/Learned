# ****** Kiểu dữ liệu Boolean ****** 
x = 0
y = 5
print(bool(x<y))