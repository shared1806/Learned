# Dictionaries giống như json
# VD:
person = {"name": "Phero", "age": 30, "male": True, "status": "maried"}

# Method: https://www.w3schools.com/python/python_ref_dictionary.asp
