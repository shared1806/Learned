a = ("John", "Charles", "Mike")
b = ("1", "2", "3")

x = zip(a, b)
# print(tuple(x))
print(set(x))