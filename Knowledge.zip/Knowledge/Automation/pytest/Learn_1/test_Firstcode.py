def test_lauchBrowser():
    print("My First Pytest code")
    assert 4 == 5

def test_lauchBrowser1():
    print("My First Pytest code")
    assert 5 == 5