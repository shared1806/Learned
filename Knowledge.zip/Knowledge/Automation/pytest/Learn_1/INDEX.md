*** ---------------- PYTEST ---------------- *** 
https://docs.pytest.org/en/7.1.x/getting-started.html
- Cách đặt tên: https://vnpro.vn/thu-vien/huong-dan-su-dung-thu-vien-pytest-3891.html

*** 1. Viết test bằng PyTest ***
https://www.youtube.com/playlist?list=PLHT5rv7PEE4O8WXZkqCse0M3QvPHr_IlB


test_Firstcode.py => chạy pytest đơn giản
test_markersDemo.py => chạy những pytest có @pytest.mark.___
test_fixture.py => sẽ chạy trước mỗi hàm
conftest.py => giống như kiểu viết hàm tái sử dụng lại
test_report.py => report HTML, screenshort


