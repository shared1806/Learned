https://anhtester.com/blog/lo-trinh-hoc-de-tro-thanh-automation-tester-b304.html

1. *** Kiến thức manual *** 
https://docs.google.com/spreadsheets/d/1Z0aYPpoZE7WRZNZgB_syDxA9AJK2DCWODCx21uByZ_A/edit#gid=518711701

2. *** Hiểu về HTML, CSS và Xpath *** 
Xpath là đường dẫn XML
Tham khảo lấy thủ công: https://www.guru99.com/xpath-selenium.html
Tool lấy Xpath: https://chrome.google.com/webstore/detail/selectorshub/ndgimibanhlabgdgjcpbbndiehljcpfh?hl=en-US

3. *** Chọn một ngôn ngữ lập trình để học *** 
Selenium java đang thông dụng
https://anhtester.com/blog/selenium-java 

4. *** Sử dụng thư viện hỗ trợ auto test *** 
- Dùng Selenium
- Appium để auto test cho Mobile

*** *** *** *** *** SETUP JDK *** *** *** *** *** 

Cài macOS ARM64 DMG Installer: https://www.oracle.com/java/technologies/javase/jdk11-archive-downloads.html 
Terminal: 
Kiểm tra version: java -version
Kiểm tra đường dẫn cài đặt môi trường java: /usr/libexec/java_home -v20 
Có thể mở bằng vscode: 
    vim ~/.bash_profile
    export JAVA_HOME=$(/usr/libexec/java_home)
Khởi chạy lại file: source ~/.bash_profile
Xem lại biến môi trường: echo $JAVA_HOME
Nếu muốn xoá jdk: sudo rm -rf /Library/Java/JavaVirtualMachines/jdk<version>.jdk


 *** *** *** *** *** Cài Eclipse IDE *** *** *** *** *** 
 
https://www.eclipse.org/downloads/packages/

