package If_Else;

public class IfElse {
	public static void main (String[] args) {
		int age = 30;
		if(age >=30) {
			System.out.println("Già rồi đó");
		}
		else {
			System.out.println("Còn trẻ nha");
		}
	}
}
