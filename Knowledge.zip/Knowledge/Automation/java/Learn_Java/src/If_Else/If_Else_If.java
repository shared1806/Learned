package If_Else;

public class If_Else_If {
	public static void main (String[] args) {
	//		xếp loại học sinh
		int mask = 10;
		if (mask <= 5) {
			System.out.println("Học sinh trung bình");
		}
		else if (mask >=6 && mask <=8) {
			System.out.println("Học sinh khá");
		}
		else if (mask >= 9 && mask <= 10) {
			System.out.println("Học sinh giỏi");
		}
		
	}
	
}
