package mypack;

public class Student1 {
//	VD: Tạo một lớp Student có hai thành viên dữ liệu là id và name. 
	int id = 1;
	String name = "Phero";
	public static void main(String args[]){  
		Student1 s = new Student1(); //tao mot doi tuong Student
		System.out.println(s.id);  
		System.out.println(s.name);  
	}
}
