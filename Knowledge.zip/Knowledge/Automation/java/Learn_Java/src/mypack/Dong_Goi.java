package mypack;
//StudentDongGoi.java
public class Dong_Goi {

	public static void main(String[] args) {
		StudentDongGoi s = new StudentDongGoi();
		s.setName("Phero");
		System.out.println("Tính đóng gói trong Java: \n"+s.getName());
	}

}