package mypack;

//Person.java là cha , StudentKeThua.java là con
public class Ke_thua {
	public static void main(String[] args) {
		StudentKeThua a = new StudentKeThua("Chau", 21, 1.7f);
		a.getInfo();
	}
}