package mypack;

public class StudentKeThua extends Person {
	public StudentKeThua(String name, int age, float height) {
		super(name, age, height);
	}	
	public void getInfo() {
		super.getInfo();
	}
}