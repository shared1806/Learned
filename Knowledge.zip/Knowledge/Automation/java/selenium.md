Selenium là một bộ kiểm thử tự động mã nguồn mở miễn phí 
Có 4 thành phần:
- Selenium Integrated Development Environment (Selenium IDE)
- Selenium Remote Control (Selenium RC)
- Selenium WebDriver (học cái này)
- Selenium Grid