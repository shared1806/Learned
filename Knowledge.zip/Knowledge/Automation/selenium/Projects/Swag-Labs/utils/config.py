
class Config:
    BASE_URL = "https://www.saucedemo.com/"
    USERNAME = "standard_user" 
    PASSWORD = "secret_sauce" 
