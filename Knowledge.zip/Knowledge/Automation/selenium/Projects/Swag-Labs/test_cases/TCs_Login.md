Login
│
├──TC01: test_login_with_valid_username_and_password
│
│
├──TC02: test_login_with_invalid_username_and_password
│
│
├──TC03: test_login_with_empty_username_and_password
│
│
└──TC04: test_login_with_username_role_Sale
