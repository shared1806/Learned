1. testCreateExcel.py => tạo data và read data trong excel
2. TestLogin_Data.py => login bằng data có sẵn từ excel
3. customChrome.py => tạo hàm chrome_setup để tái sử dụng
4. testLogin.py => tái sử dụng hàm chrome_setup để Login
5. testMini.py => Login