from selenium.webdriver.common.by import By
from testLogin import Login
from testSearch import Search


       
login = Login()
login.TCLogin()
search = Search()