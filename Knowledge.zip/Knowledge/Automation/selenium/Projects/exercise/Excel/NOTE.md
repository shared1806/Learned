Viết các hàm cơ bản hay dùng liên quan đến excel ở file XLUtils.py 
=> RunTest.py tái sử dụng lại để style color cho 2 cột