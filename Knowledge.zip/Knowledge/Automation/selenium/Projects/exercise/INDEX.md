# Website: https://cms.anhtester.com/login
# Email: admin@example.com
# Password: 123456
1. Tạo dataTest file excel demo-excel.xlsx 
2. Lấy data từ excel để viết TC_Login
<!-- Tham khảo: https://github.com/ntvan/viblo/blob/master/072018/viblo.py -->
3. Tạo hàm chrome_setup để tái sử dụng
4. Tạo các hàm cơ bản để get_Row, get_Column bóc dữ liệu từ file excel ra và style cho cột
5. SQL
- DDL - create, alter, frop, truncate
- DML - insert, update, delete
- DRL - select
- TCL - commitm rollback
- DCL - grant, rovoke