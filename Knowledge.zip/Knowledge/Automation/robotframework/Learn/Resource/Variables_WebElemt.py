
# Home page locators

HomePageSearchTextBox='xpath://input[@id="gh-ac"]'
HomePageSearchButton='xpath://input[@id="gh-btn"]'
HomePageSearchAdvanced='xpath://a[@id="gh-as-a"]'