# login 
dropdown_Login = "xpath://div[@id='top-links']//li[@class='dropdown']"
elm_link_Login = "xpath://ul//li//a[text()='Login']"
input_email = "id:input-email"
input_password = "id:input-password"
btn_Login = "xpath://input[@value='Login']"
txt_errors = "xpath://div[@class='alert alert-danger alert-dismissible']"

# element left top menu 
btn_Currency = "xpath://div[@class='pull-left']//button[@class='btn btn-link dropdown-toggle']"
elm_countCurrency=   "xpath://div[@class='pull-left']//ul[@class='dropdown-menu']//li"
elm_chosseCurrency=    "xpath://div[@class='pull-left']//ul[@class='dropdown-menu']//li[2]"
elm_btnCurrency=   "xpath://div[@class='pull-left']//button[@class='btn btn-link dropdown-toggle']//strong"

# element right top menu 
elm_countMenuTop = "xpath://div[@id='top-links']//ul[@class='list-inline']/li"
elmt_SubMenuTop = "xpath://div[@id='top-links']//ul[@class='list-inline']/li[2]"
elmt_countSubMenuTop = "//div[@id='top-links']//ul[@class='list-inline']/li[2]//li"

# logo
Logo = "id:logo"
link_Login = "xpath://div[@id='logo']//h1//a"

#search
input_search = "xpath://div[@id='search']//input[@name='search']"
btn_search = "xpath://div[@id='search']//button"
count_proSearch = "xpath://div[@class='product-layout product-grid col-lg-3 col-md-3 col-sm-6 col-xs-12']"
empty_Search = "xpath://div[@id='product-search']//p[2]"
txt_search = "xpath://div[@id='product-search']//h1"

#cart
btn_Cart = "xpath://div[@id='cart']//button"